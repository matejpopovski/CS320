# This folder contains scripts to help install project dependencies

You can run these scripts in the terminal by running `./script.sh`

The `driver-starter-code.py` is an example of how to initialize a driver using the dependencies provided by the `setup-chrome-for-mp3-tester.sh` file.
