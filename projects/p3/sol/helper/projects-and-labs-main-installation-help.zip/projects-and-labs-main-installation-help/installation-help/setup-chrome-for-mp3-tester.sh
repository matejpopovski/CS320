#!/bin/bash
echo "Installing MP3 dependencies..."
echo "Installing Chrome requirements..."
apt-get update -y
apt-get install -y wget libasound2 libgbm1 libnspr4 libnss3 libu2f-udev libvulkan1 && rm -rf /var/lib/apt/lists/*
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
apt install ./google-chrome-stable_current_amd64.deb
echo "Installing Selenium requirements..."
pip install webdriver-manager

